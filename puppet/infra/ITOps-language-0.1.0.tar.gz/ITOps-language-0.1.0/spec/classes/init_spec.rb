require 'spec_helper'
describe 'language' do

  context 'with defaults for all parameters' do
    it { should contain_class('language') }
  end
end
