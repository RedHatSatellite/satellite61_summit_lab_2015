require 'spec_helper'
describe 'timezone' do

  context 'with defaults for all parameters' do
    it { should contain_class('timezone') }
  end
end
