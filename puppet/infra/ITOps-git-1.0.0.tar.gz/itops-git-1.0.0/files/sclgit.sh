#!/bin/bash
source /opt/rh/git19/enable
export X_SCLS="`scl enable git19 'echo $X_SCLS'`"
