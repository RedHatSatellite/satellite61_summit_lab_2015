require 'puppet/util/feature'

Puppet.features.add(:treetop, :libs => ["treetop"])
